# ParcelMoover Outbound Webhooks

ParcelMoover POSTs a signed event to a vendor's registered URL every time one of their orders' status changes — the supported way to keep a vendor's system in sync, instead of polling. Registration is dashboard-side (session-authenticated, not part of `/api/v1`): **Sidebar → Account → Developer → Webhooks tab**, or `POST /api/webhooks` for a script driving the dashboard itself.

## Event & payload

Currently one event type: `order.status_changed`.

```json
{
  "id": "b6f2...",
  "type": "order.status_changed",
  "created_at": "2026-07-22T09:15:00.000Z",
  "data": {
    "trackingId": "PM-260722-XXXXXXXXXXXXX-X",
    "orderId": "b6f2...",
    "vendorId": "a1c9...",
    "oldStatus": "sent_for_delivery",
    "newStatus": "delivered",
    "changedAt": "2026-07-22T09:15:00.000Z"
  }
}
```

A `webhook.test` event (same envelope, synthetic data) can be triggered from the dashboard's "Test" button per endpoint, to verify a receiver is wired up before going live.

## Headers on every delivery

- `X-ParcelMoover-Event` — the event type.
- `X-ParcelMoover-Delivery` — a UUID unique to this delivery **attempt**; use it to de-duplicate retries (the same logical event can arrive more than once across attempts).
- `X-ParcelMoover-Signature` — `t=<unix_seconds>,v1=<hex_hmac_sha256>`, where the HMAC is computed over `"<t>.<raw_request_body>"` using the endpoint's secret (shown once, at creation/regeneration time, in the dashboard).

## Verifying the signature (Node example)

```javascript
const crypto = require("crypto");

function verifyParcelMooverSignature(rawBody, signatureHeader, secret, toleranceSeconds = 300) {
  const parts = Object.fromEntries(signatureHeader.split(",").map((p) => p.split("=")));
  const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > toleranceSeconds) return false; // stale or replayed

  const expected = crypto.createHmac("sha256", secret).update(`${t}.${rawBody}`).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(parts.v1 || "", "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
```

Always verify against the **raw** request body (before your framework parses it as JSON) — re-serializing and re-comparing JSON can produce a different byte sequence than what was actually signed, causing false rejections.

## Retries & reliability

- Return **2xx promptly** — do the real processing after responding if it's slow. A response is expected within 10 seconds; treat that the same as a failure and design for it.
- A non-2xx (or timeout) is retried with exponential backoff — roughly 30s, 1m, 2m, 4m... capped at 6h between attempts, up to **12 attempts spanning ~24 hours** total.
- If an endpoint fails its **entire** retry window **5 times in a row**, it's automatically disabled (a circuit breaker, not a one-off failure) — re-enable it from the dashboard once fixed; this also resets the failure count.
- Deliveries are queued transactionally alongside the order-status change itself, so a webhook is never fired for a status change that later gets rolled back.

## Registration URL requirements

The endpoint URL must use `https://` in production (an `http://localhost`/`127.0.0.1` exception exists for local dev only) and must not resolve to a private/reserved/link-local address (this blocks pointing a webhook at internal infrastructure or the cloud metadata endpoint, `169.254.169.254`) — registration fails fast with a clear error if either check doesn't pass, so a receiver behind a VPN-only hostname or an internal load balancer won't register at all.

## Minimal handler shape (Node/Express)

```javascript
app.post("/webhooks/parcelmoover", express.raw({ type: "application/json" }), (req, res) => {
  const signature = req.headers["x-parcelmoover-signature"];
  if (!verifyParcelMooverSignature(req.body, signature, process.env.PARCELMOOVER_WEBHOOK_SECRET)) {
    return res.status(401).end();
  }
  const event = JSON.parse(req.body);
  // enqueue event.data for async processing, keyed by X-ParcelMoover-Delivery for de-dup
  res.status(200).end();
});
```

Note the `express.raw()` body parser — you need the raw bytes for signature verification, not the JSON-parsed object Express's default `express.json()` middleware would give you.

## Troubleshooting

- **Nothing received**: is the endpoint enabled (not paused/disabled)? Publicly reachable over HTTPS? Check delivery history: **Developer → Webhooks tab → Deliveries** per endpoint, or `GET /api/webhooks/:id/deliveries`.
- **Signature never verifies**: almost always a raw-vs-parsed-body mismatch — confirm you're signing/comparing the exact bytes received, not a re-serialized object.
- **Endpoint auto-disabled**: it exhausted the full ~24h retry window 5 times in a row; fix the receiver, then re-enable it from the dashboard.
- Reconcile any gap (e.g. after downtime) with `POST /api/v1/orders/statuses` rather than assuming every event eventually arrived.
