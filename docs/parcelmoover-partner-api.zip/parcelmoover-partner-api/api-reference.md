# ParcelMoover Partner API Reference (v1)

Base URL: `<host>/api/v1`. All requests/responses are JSON. Every endpoint below except `GET /openapi.json` requires `Authorization: Bearer pm_live_...` (or `X-Api-Key: ...`).

---

## Orders

### POST /orders — create an order

Headers: `Authorization`, `Idempotency-Key` (UUID, required), `Content-Type: application/json`.

| Field | Type | Required | Notes |
|---|---|---|---|
| `receiver` | object | ✅ | `{name, phone, alternatePhone?, email?, address?, locationId?}`. |
| `receiver.name` | string | ✅ | 2–100 chars. |
| `receiver.phone` | string | ✅ | 10–15 digits, optional leading `+`. |
| `receiver.locationId` | UUID or hub name | — | Destination branch/hub, same value as `destinationLocationId`. Set both. |
| `sender` | object | — | Same shape as `receiver`. Omit to use the vendor's registered pickup profile. |
| `orderType` | string | — | `delivery` (default), `exchange`, `return`. On an `exchange` order, once ops confirms delivery a linked return parcel is auto-created — find it via the new order's `sourceOrderId` (see the track response below). |
| `serviceType` | string | — | `home_delivery` (default), `branch_delivery`. |
| `pieces` | integer | — | ≥ 1. |
| `weightKg` | number | — | > 0. |
| `codAmount` | number | — | ≥ 0. Omit/`0` for prepaid. |
| `packageType` | string | — | ≤ 50 chars, e.g. `"electronics"`. |
| `deliveryInstruction` | string | — | ≤ 500 chars. |
| `pickupAddress` | string | — | ≤ 255 chars. Overrides sender address for pickup. |
| `scheduledPickupAt` | string | — | ISO-8601 with offset, e.g. `2026-07-15T10:00:00+05:45`. |
| `originLocationId` | UUID | — | Your pickup hub; normally auto-resolved. |
| `destinationLocationId` | UUID or hub name | — | The "To" branch/hub — e.g. `"Kathmandu"` or a UUID from `GET /rates`. |
| `allowPartialDelivery` | boolean | — | Flags that this shipment (e.g. a multi-item order) may be accepted in part without failing the whole delivery. Informational only — you still read the actual outcome back via `GET /orders/:trackingId` once a rider/ops marks it `partially_delivered`. |

Response `201`:
```json
{
  "success": true,
  "message": "Order created successfully",
  "data": { "id": "uuid", "trackingId": "PM-260722-XXXXXXXXXXXXX-X", "status": "pickup_ordered", "createdAt": "2026-07-22T17:00:00.000Z" }
}
```

### GET /orders/:trackingId — track one order

Full order detail scoped to your vendor account (`404` if not found or not yours) — includes `statusHistory` (array of `{oldStatus, newStatus, remarks, changedBy, changedByType, createdAt}`) and `remarks` (the comment thread, same shape as the remarks endpoints below). Also includes:

| Field | Notes |
|---|---|
| `allowPartialDelivery` | Whatever you set at creation (`false` if omitted). |
| `partialDeliveryRemarks` / `partialCodCollected` | `null` until a rider/ops marks the parcel `partially_delivered`; then the remarks text and the COD actually collected. |
| `sourceOrderId` | Set only on an auto-created return leg — points back at the `exchange` order it was generated from. |

### GET /orders?status=&page=&pageSize= — list your orders

| Query param | Notes |
|---|---|
| `page` | Default `1`. |
| `pageSize` | Default `20`, max `100`. |
| `status` | Comma-separated, e.g. `status=delivered,cancelled`. Values from the status list in SKILL.md. |

Response: `{ success: true, data: [...], meta: { page, pageSize, total, totalPages } }`.

### PATCH /orders/:trackingId — edit an order (pre-dispatch only)

Headers: `Authorization`, `Idempotency-Key` (required). Body: any of `receiver` (full object, same shape as create), `originLocationId`, `destinationLocationId` (UUID or hub name), `orderType`, `serviceType`, `pieces`, `weightKg`, `codAmount`, `packageType`, `deliveryInstruction` — at least one field required. Use this for address/receiver corrections ("redirects") while the order is still in your hands.

Only allowed while the order is `pickup_ordered`, `rider_assigned`, or `failed_pickup` — once it's picked up and in the delivery network, returns `409` ("contact support to change it").

Response `200`: `{ "success": true, "message": "Order updated", "data": { "id", "trackingId", "status", "updatedAt" } }`.

### POST /orders/:trackingId/return-request — request a return

Headers: `Authorization`, `Idempotency-Key` (required). Body: `{ "reason": string (3–500 chars), "notes"?: string (≤2000 chars) }`.

This does **not** move the order through the return-to-vendor workflow itself — it opens a pending request (a support ticket, category `return_request`) for ops staff to review and action. Poll its resolution via `GET /tickets/:id` using the returned `ticketId`, or watch the order's own status via `GET /orders/:trackingId` for the RTO stages (`follow_up` → `ready_to_return` → `sent_to_vendor` → `returned_to_vendor`) once staff act on it. `409` if the order is already `cancelled` or `returned_to_vendor`.

Response `201`: `{ "success": true, "message": "Return request submitted", "data": { "id", "ticketId": "TKT-...", "status": "pending" } }`.

### POST /orders/:trackingId/cancel — cancel your order

Headers: `Authorization`, `Idempotency-Key` (required). Body: `{ "reason"?: string }` (≤500 chars, recorded as a remark). Only succeeds from `pickup_ordered`, `rider_assigned`, or `failed_pickup` — otherwise `409`/`422`.

Response `200`: `{ "success": true, "message": "Order cancelled", "data": { "trackingId": "...", "status": "cancelled" } }`.

### POST /orders/statuses — bulk status lookup

No `Idempotency-Key` (read-only in effect). Body: `{ "trackingIds": string[] }` (1–100). Response:
```json
{
  "success": true,
  "data": [ { "trackingId": "PM-...", "status": "delivered", "updatedAt": "2026-07-22T11:16:28.210Z" } ],
  "notFound": ["PM-unknown-id"]
}
```
IDs that don't exist or aren't yours land in `notFound`, not an error — the request as a whole still succeeds.

---

## Rates

### GET /rates — your full rate card

No params. Response:
```json
{
  "success": true,
  "data": {
    "rateType": "flat",
    "freeWeightKg": 2,
    "extraWeightPercent": 5,
    "rates": [
      { "destinationId": "uuid", "destinationName": "KATHMANDU", "zone": "urban_areas", "valley": "inside", "homeRate": 100, "branchRate": 100, "note": null }
    ]
  }
}
```
`destinationId` is a valid `destinationLocationId` for order creation and quoting; `destinationName` is what a vendor can type directly instead (case-insensitive).

### GET /rates/quote?destinationLocationId=&weightKg=&serviceType= — single-destination quote

`destinationLocationId` (required) accepts a UUID **or** a hub name/code. `weightKg` defaults to `1`. `serviceType` defaults to `home_delivery`.

Response `200`:
```json
{ "success": true, "data": { "baseCharge": 100, "weightSurcharge": 0, "totalPayable": 100, "freeWeightKg": 2, "rateType": "flat", "basis": "Flat home rate (inside valley)", "valley": "inside" } }
```
Unrecognized name/id → `400 DESTINATION_NOT_FOUND`:
```json
{ "success": false, "message": "Unknown destination hub: \"Notaplace\". See GET /api/v1/rates for valid names.", "error": { "code": "DESTINATION_NOT_FOUND" } }
```

---

## Order comments (remarks)

### GET /orders/:trackingId/remarks — read the thread

Response: `{ "success": true, "data": [ { "id", "remark", "addedBy", "createdAt", "parentRemarkId", "parentAuthor", "parentSnippet" } ] }`.

### POST /orders/:trackingId/remarks — add a comment

Headers: `Authorization`, `Idempotency-Key` (required). Body: `{ "remark": string (1–2000 chars), "parentRemarkId"?: UUID }` (reply to an existing remark). Response `201` mirrors one item of the GET shape above.

---

## Support tickets

### POST /tickets — open a ticket

Headers: `Authorization`, `Idempotency-Key` (required).

| Field | Type | Required | Notes |
|---|---|---|---|
| `subject` | string | ✅ | 3–200 chars. |
| `category` | string | — | ≤ 50 chars, e.g. `"pickup"`, `"delivery"`, `"cod_settlement"`. |
| `priority` | string | — | `low`, `medium`, `high`, `urgent`. |
| `description` | string | — | ≤ 2000 chars. |
| `customerName` / `customerPhone` | string | — | If the ticket concerns a specific customer. |

Response `201`: `{ "success": true, "message": "Ticket created", "data": { "id", "ticketId": "TKT-...", "subject", "category", "priority", "status": "pending", "assignedTo": "Unassigned", "createdAt" } }`.

### GET /tickets?status=&priority=&category=&fromDate=&toDate=&page=&pageSize= — list your tickets

Response: `{ "success": true, "data": [...], "meta": {...} }`.

### GET /tickets/:id — ticket detail + reply thread

`403`/`404` if the ticket isn't yours.

### POST /tickets/:id/replies — reply

Headers include `Idempotency-Key` (required). Body: `{ "message": string (1–2000 chars) }`.

---

## Finance (COD / settlements)

Read-only — always scoped to your own vendor account, same as everything else. Mirrors the dashboard's Finance views (there is no create/edit-settlement equivalent here; that stays admin-only).

### GET /finance/pending-cod — your current pending COD statement

Response: `{ "success": true, "data": { "vendor": {...}, "statementDate": "...", "items": [...], "totals": { "totalCod", "deliveryCharges", "payableAmount" } } }`.

### GET /finance/order-cod?status=&page=&pageSize= — per-order COD payment status

`status` is `settled` or `not_settled`. Response: `{ "success": true, "data": [...], "settledCount", "notSettledCount", "meta": {...} }`.

### GET /finance/settlements?fromDate=&toDate=&page=&pageSize= — your settlement statements

`fromDate`/`toDate` are ISO-8601 datetimes. Response: `{ "success": true, "data": [ { "id", "statementId": "STM-V-...", "transferDate", "orderCount", "amount", "status", ... } ], "meta": {...} }`.

### GET /finance/settlements/:id — line-item detail of one statement

`403`/`404` if the statement isn't yours. Response: `{ "success": true, "data": { "id", "statementId", "items": [ { "trackingId", "codAmount", "collectedAmount", "deliveryCharge", "settledAmount", ... } ], ... } }`.

### GET /finance/unsettled-orders — orders with COD collected but not yet settled

Response: `{ "success": true, "data": { "items": [...], "totalCod", "totalDeliveryCharge", "totalNetPayable" } }`.

---

## OpenAPI spec

### GET /openapi.json — machine-readable spec, no API key required

Generated live from the same Zod validators the routes enforce, so it can't drift from actual behavior. Paste the URL into Swagger Editor / Postman "Import from link" for an interactive browser, or feed it to a codegen tool for a typed client.

---

## Error shape (all endpoints)

```json
{ "success": false, "message": "human-readable text", "error": { "code": "STABLE_CODE", "fields"?: [{ "field": "receiver.phone", "message": "..." }] } }
```

| HTTP | `error.code` | Meaning |
|---|---|---|
| 400 | `VALIDATION_ERROR` | Malformed request. |
| 400 | `DESTINATION_NOT_FOUND` | Unrecognized hub name/id. |
| 401 | `UNAUTHORIZED` | Missing/invalid/revoked API key. |
| 403 | `FORBIDDEN` | Not allowed for this vendor. |
| 404 | `NOT_FOUND` | Order/ticket not found, or unknown endpoint. |
| 409 | `CONFLICT` | Idempotency key reused with a different body, or already in a terminal state. |
| 422 | `VALIDATION_ERROR` | Invalid status transition / business-rule rejection. |
| 429 | `RATE_LIMITED` | Back off and retry (see `RateLimit-*` headers). |
| 500 | `INTERNAL_ERROR` | Safe to retry a mutating call with the same `Idempotency-Key`. |

## Example — creating an order (cURL)

```bash
curl -X POST "$BASE/api/v1/orders" \
  -H "Authorization: Bearer $KEY" \
  -H "Idempotency-Key: $(uuidgen)" \
  -H "Content-Type: application/json" \
  -d '{
    "receiver": { "name": "Ram Sharma", "phone": "9841234567", "address": "Baneshwor, Kathmandu", "locationId": "Kathmandu" },
    "destinationLocationId": "Kathmandu",
    "serviceType": "home_delivery",
    "codAmount": 1500,
    "pieces": 1,
    "weightKg": 1.2,
    "deliveryInstruction": "Call before delivery"
  }'
```

Node.js, Python, and PHP equivalents (plus the full request/response tables above, rendered): `docs/PARTNER_API.md` in this repo, or `docs/partner-api.html` for the styled version with a getting-started walkthrough.
