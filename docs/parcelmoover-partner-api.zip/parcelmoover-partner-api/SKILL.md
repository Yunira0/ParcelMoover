---
name: parcelmoover-partner-api
description: Integrate a vendor's store/backend with ParcelMoover's own Partner API (/api/v1) — create/track/list/cancel/edit orders (incl. exchange orders and pre-dispatch address redirects), bulk status lookup, return requests, delivery rate quotes (by destination UUID or plain hub name like "Kathmandu"), order comments, support tickets, read-only COD/settlement finance data, and outbound order-status webhooks with HMAC signature verification. Use whenever the task involves a vendor calling ParcelMoover's API, generating or using a `pm_live_...` API key, building a checkout/fulfillment integration against ParcelMoover, or receiving `order.status_changed` webhooks from ParcelMoover. This is OUR API (vendors are the client) — do not confuse it with the ncm-api skill, which is for calling NCM (a courier ParcelMoover itself integrates with).
---

# ParcelMoover Partner API Integration

ParcelMoover exposes a vendor-facing REST API so an e-commerce store's backend can place delivery orders, track them, quote rates, and stay in sync via webhooks — without touching the ops dashboard. This skill covers authentication, idempotency, every endpoint, and webhook handling. It's the reference for building or debugging vendor-side integration code against our own API.

Full human-readable docs (source of truth for wording/examples): `docs/PARTNER_API.md` in this repo, rendered and served live at `GET /api/v1/docs` (with a try-it console at `GET /api/v1/docs/console`) — all unauthenticated. Live, always-current machine-readable spec: `GET /api/v1/openapi.json` (no key required to fetch it) — prefer this over hand-writing request shapes when you can fetch it.

## Base URL & Authentication

- Base path: `<host>/api/v1` (local dev: `http://localhost:3000/api/v1`).
- Every request needs a vendor API key: `Authorization: Bearer pm_live_<key>` (or `X-Api-Key: <key>` instead of the Authorization header — either works).
- Keys are minted from the dashboard: **Sidebar → Account → Developer → API Keys tab → Generate Key**. The full key is shown once; store it server-side only (env var / secrets manager) — never in client-side code, since anyone with the key can act as that vendor.
- A revoked or invalid key gets `401 UNAUTHORIZED` immediately.

## Idempotency (required on every mutating call)

`POST /orders`, `POST /orders/:trackingId/cancel`, `POST /orders/:trackingId/remarks`, `POST /tickets`, and `POST /tickets/:id/replies` all require an `Idempotency-Key` header — a UUID the caller generates. Retrying with the **same** key and the **same** body replays the original response instead of repeating the action (double-charging a delivery, double-posting a comment, etc.); retrying with the same key but a **different** body gets a `409 CONFLICT`. Generate a fresh UUID per distinct action, and persist it alongside whatever you're retrying (e.g. the order you're about to create) so a network-level retry reuses it rather than minting a new one.

`POST /orders/statuses` (bulk status lookup) and all `GET /finance/*` reads are the exceptions — read-only in effect, so they don't take or need an `Idempotency-Key`.

## Endpoint quick map

| Task | Method & Path | Idempotency-Key |
|---|---|---|
| Create order (incl. `orderType: "exchange"`) | `POST /orders` | required |
| Track one order | `GET /orders/:trackingId` | — |
| List your orders | `GET /orders?status=&page=&pageSize=` | — |
| Edit an order (pre-dispatch only — address/receiver "redirect", route, COD, etc.) | `PATCH /orders/:trackingId` | required |
| Request a return (pending staff review) | `POST /orders/:trackingId/return-request` | required |
| Cancel an order | `POST /orders/:trackingId/cancel` | required |
| Bulk status lookup (≤100 ids) | `POST /orders/statuses` | not used |
| Your full rate card | `GET /rates` | — |
| Single-destination quote | `GET /rates/quote?destinationLocationId=&weightKg=&serviceType=` | — |
| Read order comments | `GET /orders/:trackingId/remarks` | — |
| Add an order comment | `POST /orders/:trackingId/remarks` | required |
| Open a support ticket | `POST /tickets` | required |
| List your tickets | `GET /tickets?status=&priority=&category=&page=` | — |
| Ticket detail + replies | `GET /tickets/:id` | — |
| Reply to a ticket | `POST /tickets/:id/replies` | required |
| Pending COD statement | `GET /finance/pending-cod` | — |
| Per-order COD status | `GET /finance/order-cod?status=&page=&pageSize=` | — |
| Settlement statements | `GET /finance/settlements?fromDate=&toDate=&page=&pageSize=` | — |
| Settlement detail | `GET /finance/settlements/:id` | — |
| Unsettled orders | `GET /finance/unsettled-orders` | — |
| OpenAPI spec (no key needed) | `GET /openapi.json` | — |

Full request/response bodies, field constraints, and worked examples in four languages: read [api-reference.md](api-reference.md).
Webhook payload, signature verification, and retry behavior: read [webhooks.md](webhooks.md).

## Key domain facts

**Destinations accept a UUID or a plain hub name.** `destinationLocationId` (on create-order and rate-quote) and `receiver.locationId` all accept **either** a location UUID from `GET /rates` **or** the hub's name/code directly, e.g. `"Kathmandu"` or `"POKHARA"` — matched case-insensitively against the same active hub list the Excel rate import uses. This means a new integration can skip the rate-lookup call entirely for a first cut and just pass the city/branch name it already has. An unrecognized name is rejected immediately with `400 DESTINATION_NOT_FOUND`, not silently accepted — never assume a typo'd name will "just work."

**Create-order requires a destination, an address, COD, and weight — explicitly.** `POST /orders` rejects a payload that omits any of: a destination (`destinationLocationId` **or** `receiver.locationId`), `receiver.address` (unless `serviceType` is `branch_delivery`), `codAmount` (send `0` for prepaid), or `weightKg`. These are optional on ParcelMoover's *internal* order schema, where staff fill them in later — but on the Partner API their absence used to default silently to no rate quote, 0 COD, and 1kg, so they are hard requirements here. Never "leave it out and let the server decide."

**Sender and receiver phone numbers must differ, and both must be Nepali mobiles** — 10 digits starting `97`/`98`, optional `+977` prefix. `alternatePhone` is the looser 10–15 digit field. A same-day repeat order to the same receiver returns `409 DUPLICATE_ORDER`; resend with `confirmDuplicate: true` if it's genuinely a second parcel.

**The delivery charge is always server-computed.** It's derived from the vendor's own rate agreement (flat, zone, or per-destination) and appears on the order once fetched — there's no field to set it directly on create.

**`sender` is optional on create** — omit it and ParcelMoover fills it from the vendor's registered pickup profile (business name, phone, pickup landmark). Only pass it to override, e.g. shipping from a second warehouse.

**Order status values** (`status` field, ascending happy path): `pickup_ordered` → `rider_assigned` → `picked_up` → `arrived` → `ready_to_deliver` → `sent_for_delivery` → `delivered`. Side branches: `partially_delivered`, `failed_pickup`/`failed_delivery`, `hold`, `oov` (handed to a partner carrier), `cancelled`, `loss_and_damage`, and the return-to-vendor chain `follow_up` → `ready_to_return` → `sent_to_vendor` → `returned_to_vendor`. **Cancel only succeeds from `pickup_ordered`, `rider_assigned`, or `failed_pickup`** — once picked up, it's someone else's parcel in motion; use a comment or ticket to intervene instead, and expect `409`/`422` if you try to cancel later than that. **Editing (`PATCH`) and cancelling both share that same pre-dispatch window** — once a parcel leaves `pickup_ordered`/`rider_assigned`/`failed_pickup`, neither works; you're into a `409`.

**The return-to-vendor chain is staff-driven, not vendor-driven.** `POST /orders/:trackingId/return-request` only opens a pending request (a ticket) — it never moves the parcel through `follow_up` → `ready_to_return` → `sent_to_vendor` → `returned_to_vendor` yourself. There is no API call that advances those stages; watch the order's `status` (or the webhook) to see staff act on it.

**An `exchange` order auto-generates a linked return parcel on delivery.** You don't create the return leg yourself — when ops/rider confirms delivery of an `orderType: "exchange"` order, ParcelMoover auto-creates a second, separate parcel (the customer's old item coming back) and links it via `sourceOrderId` on that new parcel, pointing at your original order's `id`. Look it up by listing your recent orders, or reading `sourceOrderId` off orders you fetch — it isn't pushed to you by name.

**Errors are structured, not just prose.** Every error response is `{ success: false, message: "...", error: { code: "..." } }` — branch your integration logic on `error.code` (stable) rather than parsing `message` (can be reworded). Common codes: `VALIDATION_ERROR` (400/422), `UNAUTHORIZED` (401), `FORBIDDEN` (403), `NOT_FOUND` (404), `DESTINATION_NOT_FOUND` (400, unrecognized hub name/id), `CONFLICT` (409 — e.g. idempotency key reused with a different body, or order already in a terminal state), `RATE_LIMITED` (429), `INTERNAL_ERROR` (500, safe to retry a mutating call with the same idempotency key). `400` validation failures additionally carry `error.fields: [{field, message}]`.

**Rate limits are per API key, per minute**: reads 120/min, writes 30/min, bulk status lookup 20/min (a bulk call is ~100x the DB cost of a single read, so it doesn't share either budget). A `429` carries standard `RateLimit-*` headers — back off and retry after the window resets, don't just hammer it again.

## Implementation rules

1. **Prefer the webhook over polling** for status sync — `GET /orders/:trackingId` and `POST /orders/statuses` exist for on-demand lookups and reconciliation (e.g. catching up after your webhook endpoint was down), not for a scheduled polling loop against every order.
2. **Persist the `Idempotency-Key` you generate alongside the thing it's creating** (e.g. store it on your own order record before calling `POST /orders`), so a retry after a timeout or `5xx` reuses the same key instead of risking a duplicate.
3. **Resolve destinations by name when it's convenient, but cache `GET /rates` for the session** if you're building a picker UI or need the live quote — don't call it per keystroke.
4. **A vendor's own rate agreement drives pricing** — don't hardcode prices from `docs/PARTNER_API.md`'s examples; always fetch `GET /rates/quote` (or read `deliveryCharge` off the created order) for the real number.
5. **`trackingId` is the vendor-facing identifier everywhere** — never expose or ask for the internal order UUID (`id` in responses); it's an implementation detail, not part of the public contract.
6. In this repo specifically: the actual route/controller/schema code lives at `server/src/routes/publicApi.routes.ts`, `server/src/controllers/publicApi/*.ts`, and `server/src/validators/publicApi.schema.ts` — read those (not just this skill) before changing the API's behavior, since this skill documents the contract, not the implementation.
